from pathlib import Path
import py_compile
p=Path(__file__).with_name('run_phase6d2.py')
py_compile.compile(str(p), doraise=True)
print('Runner syntax: PASS')
