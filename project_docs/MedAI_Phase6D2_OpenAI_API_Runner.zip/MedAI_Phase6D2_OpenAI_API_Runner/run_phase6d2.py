#!/usr/bin/env python3
"""
MedAI/EpiSynth Phase 6D.2 frozen OpenAI API runner.

Safety/reproducibility properties:
- Reads OPENAI_API_KEY from environment; never writes it.
- Uses only Phase 6D.1 v2 frozen inputs.
- Executes C1/C2/C3 independently for each model/case.
- One application-level attempt per planned render (no selective regeneration).
- Saves raw response JSON, rendered text, request payload, hashes, timestamps.
- Does not score, adjudicate, or claim clinical validity.
"""
import os, sys, json, csv, hashlib, datetime, argparse
from pathlib import Path

try:
    from openai import OpenAI
except ImportError:
    raise SystemExit("Missing dependency. Install with: pip install -r requirements.txt")

def sha_bytes(b): return hashlib.sha256(b).hexdigest()
def sha_file(p): return sha_bytes(Path(p).read_bytes())
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()

def load_json(p):
    with open(p, encoding="utf-8") as f: return json.load(f)

def extract_text(resp):
    # Official SDK Response objects expose output_text; retain raw JSON separately.
    txt=getattr(resp,"output_text",None)
    if txt is not None: return txt
    # Defensive fallback without inventing content.
    return ""

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--freeze-dir", required=True, help="Extracted Phase 6D.1 v2 freeze directory")
    ap.add_argument("--output-dir", default="phase6d2_outputs")
    ap.add_argument("--dry-run", action="store_true")
    args=ap.parse_args()

    freeze=Path(args.freeze_dir).resolve()
    out=Path(args.output_dir).resolve()
    out.mkdir(parents=True, exist_ok=True)

    if not os.getenv("OPENAI_API_KEY") and not args.dry_run:
        raise SystemExit("OPENAI_API_KEY is not set. Key is never stored by this runner.")

    reg=load_json(freeze/"generator_registry_v2.json")
    manifest=load_json(freeze/"experiment_manifest.json")
    models=[g["model_id"] for g in reg["generators"]]
    effort={g["model_id"]:g["reasoning_effort"] for g in reg["generators"]}

    # Verify freeze hashes before any API request.
    mismatches=[]
    with open(freeze/"freeze_manifest.csv",encoding="utf-8") as f:
        for row in csv.DictReader(f):
            p=freeze/row["file"]
            if not p.exists() or sha_file(p)!=row["sha256"]:
                mismatches.append(row["file"])
    if mismatches:
        raise SystemExit("Freeze verification failed: "+", ".join(mismatches))

    client=None if args.dry_run else OpenAI()
    records=[]

    for case_path in sorted((freeze/"pilot_cases").glob("P*.json")):
        case=load_json(case_path)
        pid=case["patient_id"]
        plan=load_json(freeze/"semantic_plans"/f"{pid}.json")
        family=case["family"]

        # C0: deterministic non-LLM control, deliberately simple and auditable.
        c0_lines=[f"Synthetic {family.replace('_',' ')}."]
        for a in plan["required_assertions"]:
            c0_lines.append(f"{a['field']}: {json.dumps(a['value'], ensure_ascii=False) if isinstance(a['value'],dict) else a['value']}.")
        c0="\n".join(c0_lines)
        c0dir=out/"C0"/pid
        c0dir.mkdir(parents=True,exist_ok=True)
        (c0dir/"output.txt").write_text(c0,encoding="utf-8")
        records.append({"patient_id":pid,"condition":"C0","model":"deterministic_template",
                        "status":"completed","started_at":now(),"completed_at":now(),
                        "input_sha256":sha_file(case_path),
                        "output_sha256":sha_bytes(c0.encode()),"response_model":"NA","response_id":"NA",
                        "error":""})

        for model in models:
            for cond,fn in [("C1","C1_free_form.txt"),("C2","C2_structured_events.txt"),("C3","C3_episynth_semantic_plan.txt")]:
                template=(freeze/"prompts"/fn).read_text(encoding="utf-8")
                if cond=="C1":
                    prompt=template.format(document_family=family,
                        case_information=json.dumps(case["events"],ensure_ascii=False,indent=2))
                elif cond=="C2":
                    prompt=template.format(document_family=family,
                        structured_events=json.dumps(case["events"],ensure_ascii=False,indent=2))
                else:
                    allowed=[e for e in case["events"] if e["id"] in plan["allowed_source_event_ids"]]
                    prompt=template.format(document_family=family,
                        allowed_source_events=json.dumps(allowed,ensure_ascii=False,indent=2),
                        required_assertions=json.dumps(plan["required_assertions"],ensure_ascii=False,indent=2),
                        prohibited_assertions=json.dumps(plan["prohibited_assertions"],ensure_ascii=False,indent=2))

                rdir=out/model/cond/pid
                rdir.mkdir(parents=True,exist_ok=True)
                request={
                    "model":model,
                    "input":prompt,
                    "reasoning":{"effort":effort[model]},
                    "store":False
                }
                (rdir/"request.json").write_text(json.dumps(request,indent=2,ensure_ascii=False),encoding="utf-8")
                started=now()
                if args.dry_run:
                    records.append({"patient_id":pid,"condition":cond,"model":model,"status":"dry_run",
                                    "started_at":started,"completed_at":now(),
                                    "input_sha256":sha_bytes(prompt.encode()),"output_sha256":"",
                                    "response_model":"","response_id":"","error":""})
                    continue
                try:
                    # Exactly one application-level call. SDK transport behavior should be
                    # documented separately; no model-output regeneration is performed here.
                    resp=client.responses.create(**request)
                    completed=now()
                    raw=resp.model_dump_json(indent=2)
                    text=extract_text(resp)
                    (rdir/"response.json").write_text(raw,encoding="utf-8")
                    (rdir/"output.txt").write_text(text,encoding="utf-8")
                    meta={
                        "response_id":getattr(resp,"id",None),
                        "response_model":getattr(resp,"model",None),
                        "created_at":getattr(resp,"created_at",None),
                        "started_at":started,"completed_at":completed
                    }
                    (rdir/"metadata.json").write_text(json.dumps(meta,indent=2),encoding="utf-8")
                    records.append({"patient_id":pid,"condition":cond,"model":model,"status":"completed",
                                    "started_at":started,"completed_at":completed,
                                    "input_sha256":sha_bytes(prompt.encode()),
                                    "output_sha256":sha_bytes(text.encode()),
                                    "response_model":meta["response_model"] or "",
                                    "response_id":meta["response_id"] or "","error":""})
                except Exception as e:
                    # Preserve failure; do not silently regenerate.
                    completed=now()
                    (rdir/"error.txt").write_text(repr(e),encoding="utf-8")
                    records.append({"patient_id":pid,"condition":cond,"model":model,"status":"failed",
                                    "started_at":started,"completed_at":completed,
                                    "input_sha256":sha_bytes(prompt.encode()),"output_sha256":"",
                                    "response_model":"","response_id":"","error":repr(e)})

    fields=["patient_id","condition","model","status","started_at","completed_at","input_sha256",
            "output_sha256","response_model","response_id","error"]
    with open(out/"execution_manifest.csv","w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(records)

    run_meta={
      "phase":"6D.2",
      "created_at":now(),
      "source_freeze":str(freeze),
      "source_experiment_manifest":manifest,
      "api_key_stored":False,
      "adjudication_performed":False,
      "clinical_validity_claimed":False,
      "note":"Failures are retained as failures; reruns require a new run directory/version."
    }
    (out/"run_metadata.json").write_text(json.dumps(run_meta,indent=2),encoding="utf-8")
    print(out)

if __name__=="__main__": main()
