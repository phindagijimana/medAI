# MedAI / EpiSynth Phase 6D.2 — OpenAI API Runner

This package executes the frozen Phase 6D.1 v2 GPT multi-generator pilot.

## Scientific boundaries
- It does **not** create results until run against the API.
- It does **not** store `OPENAI_API_KEY`.
- It retains the first successful model output and does not selectively regenerate.
- Failed calls remain failures. A rerun should use a new output directory/run version.
- It does not adjudicate clinical correctness or compute performance metrics.

## Setup
1. Extract the Phase 6D.1 v2 freeze ZIP.
2. Create a Python environment.
3. `pip install -r requirements.txt`
4. Set `OPENAI_API_KEY` in your shell/environment.
5. First validate without API calls:

   `python run_phase6d2.py --freeze-dir /path/to/MedAI_Phase6D1_v2_GPT_MultiGenerator_PreRun_Freeze --output-dir run_001 --dry-run`

6. Execute:

   `python run_phase6d2.py --freeze-dir /path/to/MedAI_Phase6D1_v2_GPT_MultiGenerator_PreRun_Freeze --output-dir run_001`

## Outputs
Each GPT render stores:
- `request.json`
- `response.json`
- `output.txt`
- `metadata.json`

The run root stores:
- `execution_manifest.csv`
- `run_metadata.json`

The manifest records input/output SHA-256 hashes, requested model, API-returned model identifier, response ID, timestamps, status, and any error.

## Important
Model access is account-dependent. If an API model ID is unavailable to the executing account, the call is recorded as failed; the runner does not substitute another model.
